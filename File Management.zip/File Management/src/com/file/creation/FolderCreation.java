package com.file.creation;

import java.io.File;

public class FolderCreation {
	
	public static void main(String[] args) {
		
		String path = "C:/Users/hp/Desktop/File";
		File file = new File(path);
		
		boolean status = file.mkdir();
		
		if(status)
		{
			System.out.println("Folder Created");
		}
		else
		{
			System.out.println("Folder Not Created");
		}
	}
}
