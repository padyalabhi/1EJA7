package com.file.creation;

import java.io.File;
import java.io.IOException;

public class FileCreation {

	public static void main(String[] args) {
		
		String path = "C:/Users/hp/Desktop/File/information.txt";
		File file = new File(path);
		
		try 
		{
			if(!file.exists())
			{
				file.createNewFile();
				System.out.println("File Created");
			}
			else
			{
				System.out.println("File already exists");
			}
		
		} 
		catch (IOException e) 
		{
			System.out.println("File not created");
		}

	}

}
