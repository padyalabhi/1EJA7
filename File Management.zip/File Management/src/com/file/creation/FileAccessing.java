package com.file.creation;

import java.io.File;

public class FileAccessing {

	public static void main(String[] args) {
		
		String path = "C:/Users/hp/Desktop/File/personal.txt";
		File file = new File(path);
		
		System.out.println(file.length());

	}

}
