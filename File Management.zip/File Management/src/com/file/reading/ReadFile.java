package com.file.reading;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
		
		String path = "C:/Users/hp/Desktop/File/personal.txt";

		
		File file = new File(path);
		char[] str = new char[(int)file.length()];
		FileReader fread = null;
		
		try 
		{
			fread = new FileReader(file);
			fread.read(str);
			
			System.out.println(str);
		} 
		catch ( Exception e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				if(fread!=null)
				{
					fread.close();
				}
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}

	}

}
