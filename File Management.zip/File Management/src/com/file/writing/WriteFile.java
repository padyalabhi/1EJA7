package com.file.writing;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFile {

	public static void main(String[] args)
	{
		String path = "C:/Users/hp/Desktop/File/personal.txt";
		File file = new File(path);
		
		String info = "Go Corona !! Go Corona !!";
		
		FileWriter fwrite = null;
		
		try 
		{
			fwrite = new FileWriter(file);
			fwrite.write(info);
			fwrite.flush();
			System.out.println("Info written in file");
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			if(fwrite!=null)
			{
				try 
				{
					fwrite.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		}

	}

}
